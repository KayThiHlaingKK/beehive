//
//  VC_AllCategories.swift
//  ST Ecommerce
//
//  Created by Rishabh on 07/09/20.
//  Copyright © 2020 Shashi. All rights reserved.
//

import UIKit


class VC_AllCategories: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    //MARK:- outlets
    @IBOutlet weak var heightConstraintTopView: NSLayoutConstraint!
    @IBOutlet weak var categoriesCollectionView: UICollectionView!
    
    //MARK:- variable
    var categories = [Category]()
    let spacing:CGFloat = 5.0
    
    var myCategoryData : MyCategoryData?
    
    var apiPage = 1
    
    //MARK:- class functions
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Vidhu1")
        
        Util.configureTopViewPosition(heightConstraint: heightConstraintTopView)
        collectionViewSetUP()
        
        print("Vidhu2")
       
        
    }
    override func viewDidDisappear(_ animated: Bool) {
        collectionViewSetUP()
        self.categoriesCollectionView.reloadData()
    }
    
    
    //MARK:- function
    
    func collectionViewSetUP(){
        categoriesCollectionView.dataSource = self
        categoriesCollectionView.delegate = self
        
        categoriesCollectionView.register(UINib(nibName: "Cell_CV_Category", bundle: nil), forCellWithReuseIdentifier: "Cell_CV_Category")
        
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 12, right: 0)
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        self.categoriesCollectionView?.collectionViewLayout = layout
        
    }
    
    
    //MARK:- actions
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func refresh(_ sender: Any) {
    }
    
    
    //MARK:- collection view methods
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.categories.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell : Cell_CV_Category = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell_CV_Category", for: indexPath) as! Cell_CV_Category
        
        cell.bottomConstraintContainer.constant = 0
        cell.trailingConstraintContainer.constant = 12
        
        cell.setData(category: self.categories[indexPath.row])
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let numberOfItemsPerRow:CGFloat = 3
        //        let spacingBetweenCells:CGFloat = 5
        //
        //        let totalSpacing = (2 * self.spacing) + ((numberOfItemsPerRow - 1) * spacingBetweenCells) //Amount of total spacing in a row
        //
        //        if let collection = self.categoriesCollectionView{
        //            let width = (collection.bounds.width - totalSpacing)/numberOfItemsPerRow
        //            return CGSize(width: width, height: (width))
        //        }else{
        //            return CGSize(width: 0, height: 0)
        //        }
        let width = (collectionView.frame.size.width/numberOfItemsPerRow)
        return CGSize(width: width, height: width)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        //navigating to search controller
        let vc : VC_Store_Search = storyboardStoreSearch.instantiateViewController(withIdentifier: "VC_Store_Search") as! VC_Store_Search
        vc.category = self.categories[indexPath.row]
        vc.type = StoreProduct.viewAll
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}

// MARK: - APi Function




